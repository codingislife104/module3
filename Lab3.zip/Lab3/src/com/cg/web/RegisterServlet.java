package com.cg.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Register;
import com.cg.service.*;


@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	RegisterService regServ=null;
	private static final long serialVersionUID = 1L;
       
   public RegisterServlet() {
        super();
        
    }

	public void init(ServletConfig config) throws ServletException {
		
	}

	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		regServ=new RegisterServiceImpl();
		int dataAdded=0;
		String skills=null;
		String fname=request.getParameter("txtFname");
		String lname=request.getParameter("txtLname");
		String pwd=request.getParameter("txtPwd");
		String gen=request.getParameter("gender");
		String[] skillset = request.getParameterValues("skill");
		String city=request.getParameter("city");
		for(String s:skillset)
		{
			
		}
		Register reg=new Register(fname,lname,pwd,gen,skills,city);
		try 
		{
			dataAdded=regServ.insertData(reg);
			if(dataAdded==1)
			{
				RequestDispatcher rdSuccess=request.getRequestDispatcher("Success.html");
				rdSuccess.forward(request, response);
			}
			else
			{
				RequestDispatcher rdFailure=request.getRequestDispatcher("Failure.html");
				rdFailure.forward(request, response);
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

}
