package com.cg.service;

import com.cg.dto.Register;

public class RegisterServiceImpl implements RegisterService
{

	@Override
	public int insertData(Register reg) throws Exception {
		return insertData(reg);
	}

}
