package com.cg.service;

import com.cg.dto.Register;

public interface RegisterService 
{
	public int insertData(Register reg) throws Exception;
}
