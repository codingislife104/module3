package com.cg.dao;


import com.cg.dto.Register;

public interface RegisterDao 
{
	public int insertData(Register reg) throws Exception;
}
