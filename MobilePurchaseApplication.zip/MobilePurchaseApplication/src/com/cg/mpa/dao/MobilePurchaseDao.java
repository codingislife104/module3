package com.cg.mpa.dao;

import java.util.List;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;

public interface MobilePurchaseDao
{
	List<Mobile> getAllMobiles() throws MobileException;
	Mobile getMobile(long mid) throws MobileException;
	long insertPurchaseDetails(PurchaseDetails pDetails) throws MobileException;

}
