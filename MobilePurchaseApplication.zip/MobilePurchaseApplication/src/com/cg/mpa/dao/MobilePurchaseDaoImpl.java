package com.cg.mpa.dao;

import java.sql.Connection;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;

public class MobilePurchaseDaoImpl implements MobilePurchaseDao {

	Connection conn;
  
	@Override
	public List<Mobile> getAllMobiles() throws MobileException {
		conn=DBUtil.getConnection();
		List<Mobile> mlist=new ArrayList<>();
		try
		{
		Statement st=conn.createStatement();
		ResultSet rst=st.executeQuery(QueryMapper.SELECT_ALL_MOBILES);
		while(rst.next()){
			Mobile m=new Mobile();
			m.setMobileid(rst.getLong("mobileid"));
			m.setMname(rst.getString("name"));
			m.setPrice(rst.getDouble("price"));
			m.setQuantity(rst.getInt("quantity"));		
			mlist.add(m);
		}
		}catch(SQLException e){
			throw new MobileException("Problem in fetching mobile list while getng list");
		}
		return mlist;
	}

	@Override
	public Mobile getMobile(long mid) throws MobileException {
		conn=DBUtil.getConnection();
		Mobile m=null;
		try
		{
		PreparedStatement pst=conn.prepareStatement(QueryMapper.SELECT_MOBILE);
		pst.setLong(1, mid);
		ResultSet rst=pst.executeQuery();
		if(rst.next())
		{
			m=new Mobile();
			m.setMobileid(rst.getLong("mobileid"));
			m.setMname(rst.getString("name"));
			m.setPrice(rst.getDouble("price"));
			m.setQuantity(rst.getInt("quantity"));		
		}
		else
		{
			throw new MobileException("Mobile not found");
		}
	}
		catch(SQLException e){
		throw new MobileException("Problem in fetching mobile list");
			
		}
		return m;
	}
	private long generatePurchaseId() throws MobileException {
		long pid=0;
        conn=DBUtil.getConnection();
		try
		{
		Statement st=conn.createStatement();
		ResultSet rst=st.executeQuery(QueryMapper.SELECT_SEQUENCE);
		rst.next();
		pid=rst.getLong(1);
	}
		catch(SQLException e){
		throw new MobileException("Problem in generating purchaseid:"+e.getMessage());
	}return pid;
}

	@Override
	public long insertPurchaseDetails(PurchaseDetails pDetails)
			throws MobileException {
		 conn=DBUtil.getConnection();
		 pDetails.setPurchaseid(generatePurchaseId());
		 try
		 {
	     PreparedStatement pst=conn.prepareStatement(QueryMapper.INSERT_QUERY);
		 pst.setLong(1, pDetails.getPurchaseid());
		 pst.setString(2, pDetails.getCname());
		 pst.setString(3, pDetails.getMailid());
		 pst.setLong(4, pDetails.getPhoneno());
		 pst.setDate(5, Date.valueOf(pDetails.getPurchaseDate()));
		 pst.setLong(6, pDetails.getMobileid());
		 pst.executeUpdate();
	}catch(SQLException e){
		throw new MobileException("Problem in inserting purchasedetails"+e.getMessage());
	}
		 return pDetails.getPurchaseid();
	}
}
